package com.example.Registration;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "table1")
public class User {
    private int id;
    private String name;
    private String gender;
    private String city;

    public User() {
    }

    public User(int id, String name, String gender,String city) {
        this.id = id;
        this.setName(name);
        this.setGender(gender);
        this.setCity(city);
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   public int getId() {
        return id;
   }

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setId(Integer id2) {
		this.id=id2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}